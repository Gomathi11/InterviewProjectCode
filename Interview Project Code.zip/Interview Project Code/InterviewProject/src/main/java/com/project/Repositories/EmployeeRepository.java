package com.project.Repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.project.Model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {

}
