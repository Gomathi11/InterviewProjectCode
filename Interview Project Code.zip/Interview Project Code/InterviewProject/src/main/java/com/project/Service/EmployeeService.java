package com.project.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.Model.Employee;
import com.project.Repositories.EmployeeRepository;

import java.util.List;

import javax.transaction.Transactional;

@Service
@Transactional
public class EmployeeService {
	@Autowired
    private EmployeeRepository employeeRepository;
	
	public List<Employee> listAllEmployees() {
        return employeeRepository.findAll();
    }
     
    public Integer saveEmployeeDetails(Employee product) {
    	Employee employee = employeeRepository.save(product);
    	return employee.getId();
    }
     
    public Employee getEmployeeById(Integer id) {
        return employeeRepository.findById(id).get();
    }
     
    public void deleteEmployeeById(Integer id) {
    	employeeRepository.deleteById(id);
    }

}
